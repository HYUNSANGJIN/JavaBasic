package kr.or.bit;

public class BodyInfo {
    public int height;
    public int weight;
}
