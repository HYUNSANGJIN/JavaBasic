package kr.or.bit;

public class Car {

}
